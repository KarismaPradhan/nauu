function formValidation(){
    var firstName = document.getElementById("firstName").value;
    var lastName = document.getElementById("lastName").value;
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirmPassword").value;
    var gender = documnet.getElementById("gender").value;
    var email = document.getElementById("email").value;
    var phone = document.getElementById("phone").value;
    var address = document.getElementById("address").value;


    if(firstName==""|| lastName=="" || password=="" || confirmPassword==""||
      gender==""|| email=="" || phone=="" || address==""){
   alert("field is empty");
     return false;

  
      }esle 
      {
        return true;
      }
    
}