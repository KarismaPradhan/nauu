<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>REGISTRATION FORM</h2>
        <form onsubmit="formValidation()" action ="" method = "post">
            <label for="firstName">First Name</label>
            <input type="text" id="firstName" name="firstName" placeholder="Enter Your First  Name">

            <label for="lastName">Last Name</label>
            <input type="text" id="lastName" name="lastName" placeholder="Enter Your last Name">

            <label for="password">Password</label>
            <input type="password" id="password" name="password" placeholder="Enter Your Password">

            <label for="confirmPassword">Confirm Password</label>
            <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm Your Password">

            <!-- <label for="gender">Gender</label>
            <select id="gender" name="gender" >
            <option value="">---</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
            </select> -->

            <label for="email">Email Address</label>
            <input type="email" id="email" name="email">

            <label for="phone">Phone Number</label>
            <input type="tel" id="phone" name="phone" placeholder="Enter Phone Number">

            <label for="address">Address</label>
            <input type="text" id="address" name="address">

            <label>
                <input type="checkbox" name="terms"> Agree to terms and conditions
            </label>

            <button>Register</button>
        </form>
    </div>
<script>

function formValidation(){
    var firstName = document.getElementById("firstName").value;
    var lastName = document.getElementById("lastName").value;
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirmPassword").value;
    // var gender = documnet.getElementById("gender").value;
    var email = document.getElementById("email").value;
    var phone = document.getElementById("phone").value;
    var address = document.getElementById("address").value;


    if(firstName=="" || lastName==""||  password=="" || confirmPassword=="" || email=="" || phone=="" || address==""){
   alert("field is empty");
     return false;  
      }else if(phone.length>10|| phone.length<10){
   alert("Phone number must be of 10 digit");
    return false;

   }else if (isNaN(phone)){
    alert("Please enter a Phone no");
    return false;
    
     }else if(password!==confirmpassword){
 alert("password doesnot match");
   return false;
     }
      esle 
      {
        return true;
      }
    
}
</script>

</body>
</html>
